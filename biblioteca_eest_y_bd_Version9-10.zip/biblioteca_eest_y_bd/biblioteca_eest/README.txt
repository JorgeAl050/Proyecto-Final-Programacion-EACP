BIBLIOTECA EEST — Sistema de gestión de biblioteca escolar (versión 2)
============================================================

CONTENIDO
---------
biblioteca_eest/
├── index.php                -> Página principal (pestañas: Usuarios / Inventario / Préstamos)
├── conexion.php             -> Conexión PDO a la base de datos
├── css/style.css            -> Estilos
├── js/main.js               -> Front-end (AJAX, búsquedas, tablas, ventana de edición)
├── api/_helpers.php         -> Validaciones y cálculo de stock compartidos por las APIs
├── api/usuarios.php         -> Alta, edición, listado/búsqueda y consulta por DNI
├── api/inventario.php       -> Alta, edición y listado/búsqueda de materiales
├── api/prestamos.php        -> Alta, edición, listado/búsqueda y devolución de préstamos
└── sql/
    ├── biblioteca_eest.sql  -> Crea la base desde cero (con datos de ejemplo)
    ├── migracion_v2.sql     -> Actualiza una base de la versión 1 SIN perder datos
    └── migracion_v3.sql     -> Agrega la fecha de devolución (si ya estás en la v2)

REQUISITOS
----------
- PHP 7.4 o superior con PDO MySQL habilitado.
- MySQL / MariaDB.
- XAMPP, WAMP, Laragon o un hosting con PHP+MySQL.

INSTALACIÓN
-----------
A) Instalación nueva
   1. En phpMyAdmin importá "sql/biblioteca_eest.sql" (crea la base y las tablas).
   2. Ajustá $host, $usuario y $clave en "conexion.php" si hace falta
      (XAMPP: usuario "root", sin clave).
   3. Copiá la carpeta "biblioteca_eest" en htdocs/ y abrí
      http://localhost/biblioteca_eest/index.php

B) Ya tenías la versión anterior con datos
   1. Hacé una copia de seguridad (phpMyAdmin > Exportar).
   2. Ejecutá UNA vez, en este orden, sobre la base "biblioteca_eest":
      "sql/migracion_v2.sql" (sólo si venís de la v1) y luego "sql/migracion_v3.sql".
   3. Entrá a Inventario y revisá los totales (ver "Nota sobre el stock").
   4. Reemplazá los archivos de la carpeta del sitio por los nuevos.

FUNCIONALIDADES
---------------
USUARIOS
 - Alta con Nombre, Apellido, DNI y Dirección obligatorios; Curso opcional.
 - Tipo de usuario: Alumno, Profesor y/o Preceptor (se pueden marcar varios;
   al menos uno es obligatorio).
 - Buscador por nombre, apellido, DNI o ID.
 - EDITAR cualquier dato (el DNI no puede repetirse).
 - ELIMINAR usuarios (con confirmación). No se puede eliminar a un usuario que
   tenga préstamos sin devolver. Al eliminarlo se borran también sus préstamos
   ya devueltos y su historial (no se puede deshacer).

INVENTARIO
 - Alta de materiales (libro / revista / otros) con autor, editorial, ISBN y
   cantidad de ejemplares totales.
 - Cada material muestra: ejemplares totales, ejemplares DISPONIBLES (x de y)
   y su estado (Disponible / No disponible).
 - Buscador por ID, tipo, título, autor y editorial.
 - EDITAR cualquier dato. El total no puede quedar por debajo de los
   ejemplares que están prestados en ese momento.

PRÉSTAMOS
 - El usuario se identifica por DNI: al escribirlo, el sistema muestra en vivo
   a quién corresponde (o avisa que no existe).
 - El material se elige con una barra de búsqueda (título, autor, editorial,
   ISBN o ID) que muestra cuántos ejemplares hay disponibles de cada uno.
 - Se elige cuántos ejemplares forman parte del préstamo (máximo = disponibles).
 - EDITAR un préstamo guardado: usuario (por DNI), material y cantidad. El
   inventario se recalcula solo (si se cambia de material, el anterior se libera).
 - "Marcar devuelto": registra la fecha y la hora de devolución, REPONE los ejemplares
   al inventario y, si el material estaba agotado, vuelve a figurar
   como "Disponible". Un préstamo no puede devolverse dos veces.
 - Buscador por material, nombre del usuario, DNI o ID de usuario.
 - Todo movimiento (prestado / modificado / devuelto) queda en la tabla Historial.

NOTA SOBRE EL STOCK
-------------------
 - Inventario.Cantidad            = ejemplares totales del material.
 - Inventario.Cantidad_Disponible = totales - ejemplares en préstamos pendientes.
 - La versión anterior descontaba stock al prestar pero nunca lo reponía al
   devolver. La migración reconstruye el total como "cantidad actual +
   préstamos registrados"; si algún total no coincide con lo que tiene
   realmente la biblioteca, corregilo con el botón Editar.

ERRORES CORREGIDOS EN ESTA VERSIÓN
----------------------------------
 - Los buscadores de Usuarios y de Préstamos (por usuario) fallaban con
   "Invalid parameter number" (PDO sin emulación no admite repetir un
   mismo :marcador). Ahora cada marcador es único.
 - Devolver un préstamo no reponía el stock (el README lo prometía).
 - Se podía devolver dos veces el mismo préstamo.
 - Al importar el SQL, los acentos podían corromperse: se agregó SET NAMES utf8mb4.
 - Las altas/devoluciones usan bloqueo de fila (FOR UPDATE) para que dos
   préstamos simultáneos no superen el stock.

SEGURIDAD
---------
 - Todas las consultas usan sentencias preparadas (PDO).
 - Este sistema no tiene inicio de sesión: usalo en una red interna o agregá
   autenticación antes de publicarlo en Internet.
