<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/_helpers.php';

/** Busca un usuario por DNI exacto o lanza un error claro. */
function usuario_por_dni(PDO $pdo, $dniCrudo)
{
    $dni = normalizar_dni($dniCrudo);
    if ($dni === null) throw new ApiError('Ingresá un DNI válido (sólo números).', 422);
    $st = $pdo->prepare("SELECT Id_Usuario, Nombre, Apellido, DNI FROM Usuario WHERE DNI = :dni");
    $st->execute([':dni' => $dni]);
    $u = $st->fetch();
    if (!$u) throw new ApiError("No existe ningún usuario registrado con el DNI {$dni}.", 404);
    return $u;
}

/** Trae un material bloqueando la fila (evita que dos préstamos simultáneos se pisen). */
function item_bloqueado(PDO $pdo, $idItem)
{
    $st = $pdo->prepare("SELECT * FROM Inventario WHERE Id_Item = :id FOR UPDATE");
    $st->execute([':id' => $idItem]);
    $item = $st->fetch();
    if (!$item) throw new ApiError('El material indicado no existe.', 404);
    return $item;
}

function registrar_historial(PDO $pdo, $idPrestamo, $idUsuario, $idItem, $estado)
{
    $pdo->prepare(
        "INSERT INTO Historial (Id_Prestamo, Id_Usuario, Id_Item, Estado, Fecha)
         VALUES (:p, :u, :i, :e, CURDATE())"
    )->execute([':p' => $idPrestamo, ':u' => $idUsuario, ':i' => $idItem, ':e' => $estado]);
}

/** Verifica que haya ejemplares suficientes para $cantidad (ignorando el préstamo que se edita). */
function verificar_stock(PDO $pdo, array $item, $cantidad, $excluirPrestamo = 0)
{
    $libres = (int)$item['Cantidad'] - ejemplares_prestados($pdo, $item['Id_Item'], $excluirPrestamo);
    if ($libres < 1) {
        throw new ApiError("No hay ejemplares disponibles de \"{$item['Nombre']}\".", 409);
    }
    if ($cantidad > $libres) {
        throw new ApiError("Sólo hay {$libres} ejemplar(es) disponible(s) de \"{$item['Nombre']}\"; pediste {$cantidad}.", 409);
    }
}

ejecutar_api($pdo, function () use ($pdo) {
    $metodo = $_SERVER['REQUEST_METHOD'];

    // ------------------------------------------------------------------ LISTAR
    if ($metodo === 'GET') {
        $condiciones = [];
        $params = [];

        $material = trim($_GET['material'] ?? '');
        $usuario  = trim($_GET['usuario'] ?? '');
        $dni      = preg_replace('/[\s.\-]/', '', trim($_GET['dni'] ?? ''));
        $idUsuario = trim($_GET['id_usuario'] ?? '');

        if ($material !== '') {
            $condiciones[] = "i.Nombre LIKE :material";
            $params[':material'] = "%{$material}%";
        }
        if ($usuario !== '') {
            // Un nombre de marcador distinto por cada uso (requisito de PDO sin emulación)
            $condiciones[] = "(u.Nombre LIKE :u1 OR u.Apellido LIKE :u2 OR CONCAT(u.Nombre,' ',u.Apellido) LIKE :u3)";
            $params[':u1'] = $params[':u2'] = $params[':u3'] = "%{$usuario}%";
        }
        if ($dni !== '') {
            $condiciones[] = "u.DNI LIKE :dni";
            $params[':dni'] = "%{$dni}%";
        }
        if ($idUsuario !== '') {
            $condiciones[] = "u.Id_Usuario = :id_usuario";
            $params[':id_usuario'] = (int)$idUsuario;
        }

        $sql = "SELECT
                    p.Id_Prestamo, p.Cantidad, p.Fecha_Prestamo, p.Hora_Prestamo, p.Fecha_Devolucion, p.Hora_Devolucion, p.Estado_Devuelto,
                    u.Id_Usuario, u.Nombre AS Usuario_Nombre, u.Apellido AS Usuario_Apellido, u.DNI,
                    i.Id_Item, i.Nombre AS Item_Nombre, i.Tipo_Item, i.Autor AS Item_Autor,
                    i.Cantidad AS Item_Total, i.Cantidad_Disponible AS Item_Disponible
                FROM Prestamo p
                INNER JOIN Usuario u ON u.Id_Usuario = p.Id_Usuario
                INNER JOIN Inventario i ON i.Id_Item = p.Id_Item";
        if ($condiciones) $sql .= " WHERE " . implode(' AND ', $condiciones);
        $sql .= " ORDER BY p.Fecha_Prestamo DESC, p.Hora_Prestamo DESC, p.Id_Prestamo DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        responder(200, ['ok' => true, 'data' => $stmt->fetchAll()]);
    }

    if ($metodo !== 'POST') throw new ApiError('Método no permitido.', 405);

    $input  = leer_input();
    $accion = $input['accion'] ?? 'crear';

    // ------------------------------------------------------------------ CREAR
    if ($accion === 'crear') {
        $usuario  = usuario_por_dni($pdo, $input['dni'] ?? '');
        $idItem   = (int)($input['id_item'] ?? 0);
        if ($idItem <= 0) throw new ApiError('Seleccioná el material a prestar.', 422);
        $cantidad = validar_cantidad($input['cantidad'] ?? 1, 'Indicá cuántos ejemplares se prestan (entero mayor o igual a 1).');

        $pdo->beginTransaction();
        $item = item_bloqueado($pdo, $idItem);
        verificar_stock($pdo, $item, $cantidad);

        $pdo->prepare(
            "INSERT INTO Prestamo (Id_Usuario, Id_Item, Cantidad, Fecha_Prestamo, Hora_Prestamo, Estado_Devuelto)
             VALUES (:u, :i, :c, CURDATE(), CURTIME(), 'no')"
        )->execute([':u' => $usuario['Id_Usuario'], ':i' => $idItem, ':c' => $cantidad]);
        $idPrestamo = (int)$pdo->lastInsertId();

        registrar_historial($pdo, $idPrestamo, $usuario['Id_Usuario'], $idItem, 'prestado');
        recalcular_item($pdo, $idItem);
        $pdo->commit();

        responder(200, [
            'ok' => true, 'data' => ['Id_Prestamo' => $idPrestamo],
            'msg' => "Préstamo registrado (ID {$idPrestamo}): {$cantidad} ejemplar(es) de \"{$item['Nombre']}\" para {$usuario['Nombre']} {$usuario['Apellido']}.",
        ]);
    }

    // ------------------------------------------------------------------ EDITAR
    if ($accion === 'editar') {
        $idPrestamo = (int)($input['id_prestamo'] ?? 0);
        $usuario    = usuario_por_dni($pdo, $input['dni'] ?? '');
        $idItemNuevo = (int)($input['id_item'] ?? 0);
        if ($idItemNuevo <= 0) throw new ApiError('Seleccioná el material del préstamo.', 422);
        $cantidad = validar_cantidad($input['cantidad'] ?? 1, 'Indicá cuántos ejemplares incluye el préstamo (entero mayor o igual a 1).');

        $pdo->beginTransaction();
        $st = $pdo->prepare("SELECT * FROM Prestamo WHERE Id_Prestamo = :id FOR UPDATE");
        $st->execute([':id' => $idPrestamo]);
        $prestamo = $st->fetch();
        if (!$prestamo) throw new ApiError('Préstamo no encontrado.', 404);

        // Se bloquean los materiales involucrados siempre en el mismo orden (evita bloqueos cruzados)
        $ids = array_unique([(int)$prestamo['Id_Item'], $idItemNuevo]);
        sort($ids);
        $items = [];
        foreach ($ids as $i) $items[$i] = item_bloqueado($pdo, $i);
        $itemNuevo = $items[$idItemNuevo];

        if ($prestamo['Estado_Devuelto'] === 'no') {
            verificar_stock($pdo, $itemNuevo, $cantidad, $idPrestamo);
        } elseif ($cantidad > (int)$itemNuevo['Cantidad']) {
            throw new ApiError("\"{$itemNuevo['Nombre']}\" tiene {$itemNuevo['Cantidad']} ejemplar(es) en total.", 409);
        }

        $pdo->prepare(
            "UPDATE Prestamo SET Id_Usuario = :u, Id_Item = :i, Cantidad = :c WHERE Id_Prestamo = :p"
        )->execute([':u' => $usuario['Id_Usuario'], ':i' => $idItemNuevo, ':c' => $cantidad, ':p' => $idPrestamo]);

        registrar_historial($pdo, $idPrestamo, $usuario['Id_Usuario'], $idItemNuevo, 'modificado');
        foreach ($ids as $i) recalcular_item($pdo, $i);
        $pdo->commit();

        responder(200, ['ok' => true, 'msg' => 'Préstamo actualizado correctamente.']);
    }

    // ---------------------------------------------------------------- DEVOLVER
    if ($accion === 'devolver') {
        $idPrestamo = (int)($input['id_prestamo'] ?? 0);
        if ($idPrestamo <= 0) throw new ApiError('ID de préstamo inválido.', 422);

        $pdo->beginTransaction();
        $st = $pdo->prepare("SELECT * FROM Prestamo WHERE Id_Prestamo = :id FOR UPDATE");
        $st->execute([':id' => $idPrestamo]);
        $prestamo = $st->fetch();
        if (!$prestamo) throw new ApiError('Préstamo no encontrado.', 404);
        if ($prestamo['Estado_Devuelto'] === 'si') throw new ApiError('Este préstamo ya fue devuelto.', 409);

        $item = item_bloqueado($pdo, (int)$prestamo['Id_Item']);

        $pdo->prepare(
            "UPDATE Prestamo SET Estado_Devuelto = 'si', Fecha_Devolucion = CURDATE(), Hora_Devolucion = CURTIME() WHERE Id_Prestamo = :id"
        )->execute([':id' => $idPrestamo]);

        registrar_historial($pdo, $idPrestamo, $prestamo['Id_Usuario'], $prestamo['Id_Item'], 'devuelto');
        recalcular_item($pdo, (int)$prestamo['Id_Item']); // repone los ejemplares al inventario

        $st = $pdo->prepare("SELECT Cantidad_Disponible, Disponibilidad FROM Inventario WHERE Id_Item = :id");
        $st->execute([':id' => $prestamo['Id_Item']]);
        $inv = $st->fetch();
        $pdo->commit();

        responder(200, [
            'ok' => true,
            'msg' => "Préstamo devuelto. \"{$item['Nombre']}\": {$inv['Cantidad_Disponible']} de {$item['Cantidad']} ejemplar(es) disponible(s) ({$inv['Disponibilidad']}).",
        ]);
    }

    throw new ApiError('Acción no válida.', 400);
});
