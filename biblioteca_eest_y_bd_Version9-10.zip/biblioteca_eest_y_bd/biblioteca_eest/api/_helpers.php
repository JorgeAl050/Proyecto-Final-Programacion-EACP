<?php
/**
 * api/_helpers.php
 * Funciones y constantes compartidas por las APIs y por index.php.
 */

// Tipos de usuario permitidos (un usuario puede tener más de uno).
const TIPOS_USUARIO = ['Alumno', 'Profesor', 'Preceptor'];
// Tipos de material permitidos.
const TIPOS_ITEM = ['libro', 'revista', 'otros'];

/** Error controlado: se devuelve al navegador como JSON con el código HTTP indicado. */
class ApiError extends Exception
{
    public $codigoHttp;
    public function __construct($mensaje, $codigoHttp = 400)
    {
        parent::__construct($mensaje);
        $this->codigoHttp = $codigoHttp;
    }
}

function responder($codigo, array $payload)
{
    http_response_code($codigo);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Lee el cuerpo de la petición (JSON o formulario clásico). */
function leer_input()
{
    $in = json_decode(file_get_contents('php://input'), true);
    return is_array($in) ? $in : $_POST;
}

/** Ejecuta la lógica de una API y convierte cualquier error en una respuesta JSON. */
function ejecutar_api(PDO $pdo, callable $fn)
{
    try {
        $fn();
    } catch (ApiError $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        responder($e->codigoHttp, ['ok' => false, 'error' => $e->getMessage()]);
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        responder(500, ['ok' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
    }
}

/** Quita puntos, espacios y guiones del DNI. Devuelve null si no es válido. */
function normalizar_dni($dni)
{
    $d = preg_replace('/[\s.\-]/', '', (string)$dni);
    return preg_match('/^\d{6,10}$/', $d) ? $d : null;
}

/** Acepta array o texto "Profesor, Preceptor" y devuelve sólo tipos válidos, sin repetir. */
function normalizar_tipos($valor)
{
    if (is_string($valor)) {
        $valor = preg_split('/\s*[,;]\s*/', $valor, -1, PREG_SPLIT_NO_EMPTY);
    }
    if (!is_array($valor)) return [];
    $res = [];
    foreach (TIPOS_USUARIO as $permitido) {
        foreach ($valor as $v) {
            if (strtolower(trim((string)$v)) === strtolower($permitido)) {
                $res[] = $permitido;
                break;
            }
        }
    }
    return $res;
}

/** Cantidad de ejemplares: entero >= 1. */
function validar_cantidad($valor, $mensaje = 'La cantidad debe ser un número entero mayor o igual a 1.')
{
    $n = filter_var($valor, FILTER_VALIDATE_INT);
    if ($n === false || $n < 1) {
        throw new ApiError($mensaje, 422);
    }
    return $n;
}

/**
 * Recalcula Cantidad_Disponible y Disponibilidad de un material a partir de
 * su cantidad total y de los préstamos que todavía no fueron devueltos.
 * Se llama después de cualquier alta/edición/devolución de préstamo y
 * después de editar un material, así el inventario nunca queda desfasado.
 */
function recalcular_item(PDO $pdo, $idItem)
{
    $pdo->prepare(
        "UPDATE Inventario i
            SET i.Cantidad_Disponible = GREATEST(CAST(i.Cantidad AS SIGNED) - (
                    SELECT COALESCE(SUM(p.Cantidad), 0) FROM Prestamo p
                     WHERE p.Id_Item = i.Id_Item AND p.Estado_Devuelto = 'no'), 0)
          WHERE i.Id_Item = :id"
    )->execute([':id' => $idItem]);

    $pdo->prepare(
        "UPDATE Inventario
            SET Disponibilidad = IF(Cantidad_Disponible > 0, 'Disponible', 'No Disponible')
          WHERE Id_Item = :id"
    )->execute([':id' => $idItem]);
}

/** Ejemplares prestados (sin devolver) de un material, opcionalmente ignorando un préstamo. */
function ejemplares_prestados(PDO $pdo, $idItem, $excluirPrestamo = 0)
{
    $st = $pdo->prepare(
        "SELECT COALESCE(SUM(Cantidad), 0) FROM Prestamo
          WHERE Id_Item = :i AND Estado_Devuelto = 'no' AND Id_Prestamo <> :p"
    );
    $st->execute([':i' => $idItem, ':p' => $excluirPrestamo]);
    return (int)$st->fetchColumn();
}
