<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/_helpers.php';

/** Valida y limpia los datos de un material (alta y edición). */
function datos_item(array $input)
{
    $tipo      = strtolower(trim($input['tipo_item'] ?? ''));
    $nombre    = trim($input['nombre'] ?? '');
    $isbn      = trim($input['isbn'] ?? '');
    $editorial = trim($input['editorial'] ?? '');
    $autor     = trim($input['autor'] ?? '');

    $errores = [];
    if (!in_array($tipo, TIPOS_ITEM, true)) $errores[] = 'El tipo de material debe ser: ' . implode(', ', TIPOS_ITEM) . '.';
    if ($nombre === '') $errores[] = 'El nombre/título es obligatorio.';
    $cantidad = filter_var($input['cantidad'] ?? '', FILTER_VALIDATE_INT);
    if ($cantidad === false || $cantidad < 1) $errores[] = 'La cantidad debe ser un número entero mayor o igual a 1.';
    if ($errores) throw new ApiError(implode(' ', $errores), 422);

    return [
        ':tipo'      => $tipo,
        ':nombre'    => $nombre,
        ':cantidad'  => $cantidad,
        ':isbn'      => $isbn !== '' ? $isbn : null,
        ':editorial' => $editorial !== '' ? $editorial : null,
        ':autor'     => $autor !== '' ? $autor : null,
    ];
}

ejecutar_api($pdo, function () use ($pdo) {
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        $condiciones = [];
        $params = [];

        $mapa = [ // parámetro GET => [columna, usa LIKE]
            'tipo'      => ['Tipo_Item', true],
            'nombre'    => ['Nombre', true],
            'autor'     => ['Autor', true],
            'editorial' => ['Editorial', true],
        ];
        if (trim($_GET['id'] ?? '') !== '') {
            $condiciones[] = "Id_Item = :id";
            $params[':id'] = (int)$_GET['id'];
        }
        foreach ($mapa as $clave => [$columna]) {
            $v = trim($_GET[$clave] ?? '');
            if ($v !== '') {
                $condiciones[] = "{$columna} LIKE :{$clave}";
                $params[":{$clave}"] = "%{$v}%";
            }
        }
        // Búsqueda general (la usa el selector de material de los préstamos)
        $q = trim($_GET['q'] ?? '');
        if ($q !== '') {
            $condiciones[] = "(Nombre LIKE :q1 OR Autor LIKE :q2 OR Editorial LIKE :q3
                               OR Isbn LIKE :q4 OR Id_Item = :qid)";
            $params[':q1'] = $params[':q2'] = $params[':q3'] = $params[':q4'] = "%{$q}%";
            $params[':qid'] = is_numeric($q) ? (int)$q : -1;
        }

        $sql = "SELECT Id_Item, Tipo_Item, Disponibilidad, Nombre, Cantidad, Cantidad_Disponible,
                       Isbn, Editorial, Autor
                  FROM Inventario";
        if ($condiciones) $sql .= " WHERE " . implode(' AND ', $condiciones);
        $sql .= " ORDER BY Id_Item DESC";
        $limite = (int)($_GET['limite'] ?? 0);
        if ($limite > 0) $sql .= " LIMIT " . min($limite, 100);

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        responder(200, ['ok' => true, 'data' => $stmt->fetchAll()]);
    }

    if ($metodo === 'POST') {
        $input  = leer_input();
        $accion = $input['accion'] ?? 'crear';

        if ($accion === 'crear') {
            $d = datos_item($input);
            $d[':disp'] = $d[':cantidad']; // al crear, todos los ejemplares están disponibles
            $pdo->prepare(
                "INSERT INTO Inventario (Tipo_Item, Disponibilidad, Nombre, Cantidad, Cantidad_Disponible, Isbn, Editorial, Autor)
                 VALUES (:tipo, 'Disponible', :nombre, :cantidad, :disp, :isbn, :editorial, :autor)"
            )->execute($d);
            $id = (int)$pdo->lastInsertId();
            responder(200, [
                'ok' => true, 'data' => ['Id_Item' => $id],
                'msg' => "Material registrado correctamente con ID {$id}.",
            ]);
        }

        if ($accion === 'editar') {
            $id = (int)($input['id_item'] ?? 0);
            $d  = datos_item($input);

            $pdo->beginTransaction();
            $st = $pdo->prepare("SELECT Id_Item FROM Inventario WHERE Id_Item = :id FOR UPDATE");
            $st->execute([':id' => $id]);
            if (!$st->fetch()) throw new ApiError('El material no existe.', 404);

            // No se puede bajar el total por debajo de lo que está prestado hoy
            $prestados = ejemplares_prestados($pdo, $id);
            if ($d[':cantidad'] < $prestados) {
                throw new ApiError(
                    "No podés dejar el total en {$d[':cantidad']}: hay {$prestados} ejemplar(es) prestado(s) en este momento.",
                    409
                );
            }
            $d[':id'] = $id;
            $pdo->prepare(
                "UPDATE Inventario SET Tipo_Item = :tipo, Nombre = :nombre, Cantidad = :cantidad,
                        Isbn = :isbn, Editorial = :editorial, Autor = :autor
                  WHERE Id_Item = :id"
            )->execute($d);
            recalcular_item($pdo, $id);
            $pdo->commit();

            responder(200, ['ok' => true, 'msg' => 'Material actualizado correctamente.']);
        }

        throw new ApiError('Acción no válida.', 400);
    }

    throw new ApiError('Método no permitido.', 405);
});
