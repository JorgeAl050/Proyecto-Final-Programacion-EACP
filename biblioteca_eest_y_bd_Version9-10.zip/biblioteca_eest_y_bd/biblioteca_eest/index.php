<?php
// index.php — Sistema de Biblioteca EEST
// Requiere conexion.php sólo para validar que la BD responde al cargar la página.
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/api/_helpers.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Biblioteca EEST</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="site-header">
  <h1>📚 Biblioteca EEST</h1>
  <p>Sistema de gestión de usuarios, inventario y préstamos</p>
</header>

<nav class="tabs">
  <button type="button" class="tab-btn active" data-tab="usuarios">Usuarios</button>
  <button type="button" class="tab-btn" data-tab="inventario">Inventario</button>
  <button type="button" class="tab-btn" data-tab="prestamos">Préstamos</button>
</nav>

<main>

  <!-- ============ PESTAÑA USUARIOS ============ -->
  <section id="tab-usuarios" class="tab-panel active">

    <div class="card">
      <h2>Registrar nuevo usuario</h2>
      <div id="msg-usuario" class="msg"></div>
      <form id="form-usuario" class="form-grid">
        <div class="form-field">
          <label for="u-nombre">Nombre *</label>
          <input type="text" id="u-nombre" name="nombre" required>
        </div>
        <div class="form-field">
          <label for="u-apellido">Apellido *</label>
          <input type="text" id="u-apellido" name="apellido" required>
        </div>
        <div class="form-field">
          <label for="u-dni">DNI *</label>
          <input type="text" id="u-dni" name="dni" required>
        </div>
        <div class="form-field">
          <label for="u-direccion">Dirección *</label>
          <input type="text" id="u-direccion" name="direccion" required>
        </div>
        <div class="form-field">
          <label for="u-curso">Curso (opcional)</label>
          <input type="text" id="u-curso" name="curso" placeholder="Ej: 5to A">
        </div>
        <div class="form-field">
          <label>Tipo de usuario * <small>(podés marcar más de uno, debe seleccionar aunque sea uno)</small></label>
          <div class="checks" id="u-tipos">
<?php foreach (TIPOS_USUARIO as $i => $tipo): ?>
            <label class="check"><input type="checkbox" name="tipo_usuario" value="<?= htmlspecialchars($tipo) ?>"<?= $i === 0 ? ' checked' : '' ?>> <?= htmlspecialchars($tipo) ?></label>
<?php endforeach; ?>
          </div>
        </div>
        <div class="form-actions">
          <button type="submit" class="btn">Registrar usuario</button>
          <button type="reset" class="btn secundario">Limpiar</button>
        </div>
      </form>
    </div>

    <div class="card">
      <h2>Usuarios registrados</h2>
      <div class="search-grid">
        <div class="form-field">
          <label for="buscar-usuario">Buscar (nombre, apellido, DNI o ID)</label>
          <input type="text" id="buscar-usuario" placeholder="Escribí para filtrar...">
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Nombre</th><th>Apellido</th><th>DNI</th>
              <th>Dirección</th><th>Curso</th><th>Tipo</th><th>Acciones</th>
            </tr>
          </thead>
          <tbody id="tabla-usuarios"></tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- ============ PESTAÑA INVENTARIO ============ -->
  <section id="tab-inventario" class="tab-panel">

    <div class="card">
      <h2>Registrar nuevo material</h2>
      <div id="msg-inventario" class="msg"></div>
      <form id="form-inventario" class="form-grid">
        <div class="form-field">
          <label for="i-tipo">Tipo de material *</label>
          <select id="i-tipo" name="tipo_item" required>
            <option value="libro">Libro</option>
            <option value="revista">Revista</option>
            <option value="otros">Otros</option>
          </select>
        </div>
        <div class="form-field">
          <label for="i-nombre">Título / Nombre *</label>
          <input type="text" id="i-nombre" name="nombre" required>
        </div>
        <div class="form-field">
          <label for="i-autor">Autor</label>
          <input type="text" id="i-autor" name="autor">
        </div>
        <div class="form-field">
          <label for="i-editorial">Editorial</label>
          <input type="text" id="i-editorial" name="editorial">
        </div>
        <div class="form-field">
          <label for="i-isbn">ISBN</label>
          <input type="text" id="i-isbn" name="isbn">
        </div>
        <div class="form-field">
          <label for="i-cantidad">Ejemplares totales *</label>
          <input type="number" id="i-cantidad" name="cantidad" min="1" value="1" required>
        </div>
        <div class="form-actions">
          <button type="submit" class="btn">Registrar material</button>
          <button type="reset" class="btn secundario">Limpiar</button>
        </div>
      </form>
    </div>

    <div class="card">
      <h2>Inventario actual</h2>
      <div class="search-grid">
        <div class="form-field">
          <label for="inv-id">ID</label>
          <input type="number" id="inv-id" min="1">
        </div>
        <div class="form-field">
          <label for="inv-tipo">Tipo</label>
          <input type="text" id="inv-tipo" placeholder="libro, revista...">
        </div>
        <div class="form-field">
          <label for="inv-nombre">Título / Nombre</label>
          <input type="text" id="inv-nombre">
        </div>
        <div class="form-field">
          <label for="inv-autor">Autor</label>
          <input type="text" id="inv-autor">
        </div>
        <div class="form-field">
          <label for="inv-editorial">Editorial</label>
          <input type="text" id="inv-editorial">
        </div>
        <div class="form-actions">
          <button type="button" id="btn-buscar-inventario" class="btn">Buscar</button>
          <button type="button" id="btn-limpiar-inventario" class="btn secundario">Limpiar filtros</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Tipo</th><th>Título</th><th>Autor</th>
              <th>Editorial</th><th>ISBN</th><th>Total</th><th>Disponibles</th><th>Estado</th><th>Acciones</th>
            </tr>
          </thead>
          <tbody id="tabla-inventario"></tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- ============ PESTAÑA PRÉSTAMOS ============ -->
  <section id="tab-prestamos" class="tab-panel">

    <div class="card">
      <h2>Registrar nuevo préstamo</h2>
      <div id="msg-prestamo" class="msg"></div>
      <form id="form-prestamo" class="form-grid" autocomplete="off">
        <div class="form-field">
          <label for="p-dni">DNI del usuario *</label>
          <input type="text" id="p-dni" name="dni" inputmode="numeric" placeholder="Ej: 30111222" required>
          <small id="p-dni-estado" class="estado-campo"></small>
        </div>
        <div class="form-field ancho">
          <label for="p-material-buscar">Material * <small>(buscá por título, autor, editorial, ISBN o ID)</small></label>
          <div id="p-material-selector"></div>
        </div>
        <div class="form-field">
          <label for="p-cantidad">Ejemplares a prestar *</label>
          <input type="number" id="p-cantidad" name="cantidad" min="1" value="1" required disabled>
          <small id="p-cantidad-ayuda" class="estado-campo">Elegí primero un material.</small>
        </div>
        <div class="form-actions">
          <button type="submit" class="btn">Registrar préstamo</button>
          <button type="reset" class="btn secundario">Limpiar</button>
        </div>
      </form>
    </div>

    <div class="card">
      <h2>Préstamos registrados</h2>
      <div class="search-grid">
        <div class="form-field">
          <label for="pr-material">Material</label>
          <input type="text" id="pr-material" placeholder="Título del material...">
        </div>
        <div class="form-field">
          <label for="pr-usuario">Nombre del usuario</label>
          <input type="text" id="pr-usuario" placeholder="Nombre o apellido...">
        </div>
        <div class="form-field">
          <label for="pr-dni">DNI</label>
          <input type="text" id="pr-dni" inputmode="numeric" placeholder="DNI del usuario...">
        </div>
        <div class="form-field">
          <label for="pr-id-usuario">ID de usuario</label>
          <input type="number" id="pr-id-usuario" min="1">
        </div>
        <div class="form-actions">
          <button type="button" id="btn-buscar-prestamos" class="btn">Buscar</button>
          <button type="button" id="btn-limpiar-prestamos" class="btn secundario">Limpiar filtros</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Usuario</th><th>DNI</th><th>Material</th><th>Ejemplares</th>
              <th>Fecha préstamo</th><th>Hora préstamo</th><th>Fecha devolución</th><th>Hora devolución</th><th>Estado</th><th>Acciones</th>
            </tr>
          </thead>
          <tbody id="tabla-prestamos"></tbody>
        </table>
      </div>
    </div>
  </section>

</main>

<!-- Ventana de edición (la usan Usuarios, Inventario y Préstamos) -->
<div id="modal" class="modal-overlay" hidden>
  <div class="modal-box" role="dialog" aria-modal="true" aria-labelledby="modal-titulo">
    <h2 id="modal-titulo"></h2>
    <div id="modal-msg" class="msg"></div>
    <form id="modal-form" class="form-grid" autocomplete="off"></form>
  </div>
</div>

<footer class="site-footer">Biblioteca EEST &middot; Sistema interno de gestión</footer>

<script>
  window.TIPOS_USUARIO = <?= json_encode(TIPOS_USUARIO, JSON_UNESCAPED_UNICODE) ?>;
  window.TIPOS_ITEM = <?= json_encode(TIPOS_ITEM) ?>;
</script>
<script src="js/main.js"></script>
</body>
</html>
