<?php
/**
 * conexion.php
 * Conexión a la base de datos "biblioteca_eest" usando PDO.
 * Ajustá $host, $usuario, $clave según tu servidor (XAMPP/WAMP/hosting).
 */

$host    = 'localhost';
$dbname  = 'biblioteca_eest';
$usuario = 'root';
$clave   = ''; // en XAMPP por defecto la clave de root está vacía

$dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";

$opciones = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $usuario, $clave, $opciones);
} catch (PDOException $e) {
    http_response_code(500);
    // Si se está llamando desde la API devolvemos JSON, si no, texto plano.
    if (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok'    => false,
            'error' => 'No se pudo conectar a la base de datos: ' . $e->getMessage(),
        ]);
    } else {
        echo 'Error de conexión a la base de datos: ' . htmlspecialchars($e->getMessage());
    }
    exit;
}
