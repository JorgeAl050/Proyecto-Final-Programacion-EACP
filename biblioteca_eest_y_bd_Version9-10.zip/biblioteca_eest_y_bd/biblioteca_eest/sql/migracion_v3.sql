-- =====================================================================
-- MIGRACIÓN v3: fecha de devolución en los préstamos
-- Ejecutar UNA sola vez (después de migracion_v2.sql si venís de la v1).
-- =====================================================================
SET NAMES utf8mb4;
USE `biblioteca_eest`;

ALTER TABLE `Prestamo`
  ADD COLUMN `Fecha_Devolucion` DATE NULL AFTER `Hora_Prestamo`;

-- Los préstamos ya devueltos no tenían guardada la fecha: se toma la del
-- historial de devolución y, si no hay, la fecha del préstamo.
UPDATE `Prestamo` p
   SET p.`Fecha_Devolucion` = COALESCE(
         (SELECT MAX(h.`Fecha`) FROM `Historial` h
           WHERE h.`Id_Prestamo` = p.`Id_Prestamo` AND h.`Estado` = 'devuelto'),
         p.`Fecha_Prestamo`)
 WHERE p.`Estado_Devuelto` = 'si';
