-- =====================================================================
-- MIGRACIÓN a la versión 2 (conserva los datos existentes)
-- Ejecutar UNA sola vez sobre la base "biblioteca_eest" ya creada.
-- Hacé una copia de seguridad antes (phpMyAdmin > Exportar).
--
-- Nota sobre el stock: en la versión anterior "Inventario.Cantidad" se
-- iba descontando con cada préstamo y NUNCA se reponía al devolver.
-- Por eso el total original se reconstruye como:
--     total = Cantidad actual + cantidad de préstamos registrados del material
-- Revisá los totales en la pestaña Inventario y corregilos con "Editar"
-- si alguno no coincide con lo que realmente tiene la biblioteca.
-- =====================================================================

SET NAMES utf8mb4;
USE `biblioteca_eest`;

-- 1) Nuevas columnas
ALTER TABLE `Prestamo`
  ADD COLUMN `Cantidad` INT UNSIGNED NOT NULL DEFAULT 1 AFTER `Id_Item`;

ALTER TABLE `Inventario`
  ADD COLUMN `Cantidad_Disponible` INT NOT NULL DEFAULT 0 AFTER `Cantidad`;

ALTER TABLE `Usuario`
  MODIFY COLUMN `Tipo_Usuario` VARCHAR(60) NOT NULL DEFAULT 'Alumno';

-- 2) Reconstruir totales y disponibles del inventario
UPDATE `Inventario` i
   SET i.`Cantidad` = i.`Cantidad` +
       (SELECT COUNT(*) FROM `Prestamo` p WHERE p.`Id_Item` = i.`Id_Item`);

UPDATE `Inventario` i
   SET i.`Cantidad_Disponible` = GREATEST(CAST(i.`Cantidad` AS SIGNED) -
       (SELECT COALESCE(SUM(p.`Cantidad`), 0) FROM `Prestamo` p
         WHERE p.`Id_Item` = i.`Id_Item` AND p.`Estado_Devuelto` = 'no'), 0);

UPDATE `Inventario`
   SET `Disponibilidad` = IF(`Cantidad_Disponible` > 0, 'Disponible', 'No Disponible');

-- 3) Tipos de usuario: Alumno / Profesor / Preceptor
UPDATE `Usuario` SET `Tipo_Usuario` = 'Alumno'    WHERE LOWER(`Tipo_Usuario`) IN ('estudiante', 'alumno', 'otro');
UPDATE `Usuario` SET `Tipo_Usuario` = 'Profesor'  WHERE LOWER(`Tipo_Usuario`) = 'profesor';
UPDATE `Usuario` SET `Tipo_Usuario` = 'Preceptor' WHERE LOWER(`Tipo_Usuario`) IN ('administrativo', 'preceptor');
-- (Los "otro" quedaron como Alumno: corregilos con "Editar" si hace falta.)
