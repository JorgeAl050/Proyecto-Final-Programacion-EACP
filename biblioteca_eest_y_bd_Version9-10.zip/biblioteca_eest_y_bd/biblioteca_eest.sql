-- =====================================================================
-- Base de datos: biblioteca_eest  (versión 2)
--
-- Cambios respecto a la versión anterior:
--   * Usuario.Tipo_Usuario admite "Alumno", "Profesor" y/o "Preceptor"
--     (si tiene más de un rol se guardan separados por coma).
--   * Inventario.Cantidad            = ejemplares TOTALES del material.
--   * Inventario.Cantidad_Disponible = ejemplares que hay en biblioteca
--                                      (total - ejemplares prestados).
--   * Inventario.Disponibilidad      = 'Disponible' / 'No Disponible'
--                                      (se recalcula sola en la API).
--   * Prestamo.Cantidad              = cuántos ejemplares incluye el préstamo.
--   * Prestamo.Fecha_Devolucion      = día en que se devolvió el préstamo.
--
-- Si ya tenés datos cargados y NO querés perderlos, no ejecutes este
-- script: usá sql/migracion_v2.sql.
-- =====================================================================

SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `biblioteca_eest`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `biblioteca_eest`;

DROP TABLE IF EXISTS `Historial`;
DROP TABLE IF EXISTS `Prestamo`;
DROP TABLE IF EXISTS `Inventario`;
DROP TABLE IF EXISTS `Usuario`;

-- ---------------------------------------------------------------------
-- Tabla: Usuario
-- ---------------------------------------------------------------------
CREATE TABLE `Usuario` (
  `Id_Usuario`   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nombre`       VARCHAR(100) NOT NULL,
  `Apellido`     VARCHAR(100) NOT NULL,
  `DNI`          VARCHAR(20)  NOT NULL,
  `Direccion`    VARCHAR(255) NULL,
  `Curso`        VARCHAR(50)  NULL,
  `Tipo_Usuario` VARCHAR(60)  NOT NULL DEFAULT 'Alumno',
  PRIMARY KEY (`Id_Usuario`),
  UNIQUE KEY `uq_usuario_dni` (`DNI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Tabla: Inventario
-- ---------------------------------------------------------------------
CREATE TABLE `Inventario` (
  `Id_Item`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Tipo_Item`           VARCHAR(50)  NOT NULL,
  `Disponibilidad`      VARCHAR(20)  NOT NULL DEFAULT 'Disponible',
  `Nombre`              VARCHAR(255) NOT NULL,
  `Cantidad`            INT UNSIGNED NOT NULL DEFAULT 1,
  `Cantidad_Disponible` INT          NOT NULL DEFAULT 0,
  `Isbn`                VARCHAR(20)  NULL,
  `Editorial`           VARCHAR(150) NULL,
  `Autor`               VARCHAR(150) NULL,
  PRIMARY KEY (`Id_Item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Tabla: Prestamo
-- ---------------------------------------------------------------------
CREATE TABLE `Prestamo` (
  `Id_Prestamo`      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Id_Usuario`       INT UNSIGNED NOT NULL,
  `Id_Item`          INT UNSIGNED NOT NULL,
  `Cantidad`         INT UNSIGNED NOT NULL DEFAULT 1,
  `Fecha_Prestamo`   DATE NOT NULL,
  `Hora_Prestamo`    TIME NOT NULL,
  `Fecha_Devolucion` DATE NULL,
  `Hora_Devolucion`  TIME NULL,
  `Estado_Devuelto`  VARCHAR(10) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`Id_Prestamo`),
  KEY `fk_prestamo_usuario` (`Id_Usuario`),
  KEY `fk_prestamo_item` (`Id_Item`),
  CONSTRAINT `fk_prestamo_usuario` FOREIGN KEY (`Id_Usuario`)
    REFERENCES `Usuario` (`Id_Usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_prestamo_item` FOREIGN KEY (`Id_Item`)
    REFERENCES `Inventario` (`Id_Item`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Tabla: Historial  (Estado: 'prestado', 'modificado', 'devuelto')
-- ---------------------------------------------------------------------
CREATE TABLE `Historial` (
  `Id_Historial` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Id_Prestamo`  INT UNSIGNED NOT NULL,
  `Id_Usuario`   INT UNSIGNED NOT NULL,
  `Id_Item`      INT UNSIGNED NOT NULL,
  `Estado`       VARCHAR(50) NOT NULL,
  `Fecha`        DATE NOT NULL,
  PRIMARY KEY (`Id_Historial`),
  KEY `fk_historial_prestamo` (`Id_Prestamo`),
  KEY `fk_historial_usuario` (`Id_Usuario`),
  KEY `fk_historial_item` (`Id_Item`),
  CONSTRAINT `fk_historial_prestamo` FOREIGN KEY (`Id_Prestamo`)
    REFERENCES `Prestamo` (`Id_Prestamo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_historial_usuario` FOREIGN KEY (`Id_Usuario`)
    REFERENCES `Usuario` (`Id_Usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_historial_item` FOREIGN KEY (`Id_Item`)
    REFERENCES `Inventario` (`Id_Item`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Datos de ejemplo (podés borrar este bloque si preferís la base vacía)
-- ---------------------------------------------------------------------
INSERT INTO `Usuario` (`Nombre`, `Apellido`, `DNI`, `Direccion`, `Curso`, `Tipo_Usuario`) VALUES
('Juan',  'Pérez',     '30111222', 'Calle Falsa 123',     '5to A', 'Alumno'),
('María', 'Gómez',     '28555666', 'Av. Siempreviva 742', NULL,    'Profesor'),
('Laura', 'Fernández', '25999888', 'San Martín 456',      NULL,    'Profesor, Preceptor');

INSERT INTO `Inventario` (`Tipo_Item`, `Disponibilidad`, `Nombre`, `Cantidad`, `Cantidad_Disponible`, `Isbn`, `Editorial`, `Autor`) VALUES
('libro',   'Disponible', 'Cien Años de Soledad',     3, 3, '9780307474728', 'Sudamericana',       'Gabriel García Márquez'),
('libro',   'Disponible', 'El Principito',            5, 3, '9780156012195', 'Reynal & Hitchcock', 'Antoine de Saint-Exupéry'),
('revista', 'Disponible', 'National Geographic Nº120', 2, 2, NULL,           'National Geographic', NULL);

-- Préstamo 1 ya devuelto (1 ejemplar) y préstamo 2 pendiente (2 ejemplares)
INSERT INTO `Prestamo` (`Id_Usuario`, `Id_Item`, `Cantidad`, `Fecha_Prestamo`, `Hora_Prestamo`, `Fecha_Devolucion`, `Hora_Devolucion`, `Estado_Devuelto`) VALUES
(1, 1, 1, '2026-09-10', '09:15:00', '2026-09-10', '10:00:00', 'si'),
(2, 2, 2, '2026-09-20', '11:30:00', NULL,         NULL,       'no');

INSERT INTO `Historial` (`Id_Prestamo`, `Id_Usuario`, `Id_Item`, `Estado`, `Fecha`) VALUES
(1, 1, 1, 'prestado', '2026-09-10'),
(1, 1, 1, 'devuelto', '2026-09-10'),
(2, 2, 2, 'prestado', '2026-09-20');
