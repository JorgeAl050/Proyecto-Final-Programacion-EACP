<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/_helpers.php';

/** Valida y limpia los datos de un usuario (alta y edición). */
function datos_usuario(array $input)
{
    $nombre    = trim($input['nombre'] ?? '');
    $apellido  = trim($input['apellido'] ?? '');
    $direccion = trim($input['direccion'] ?? '');
    $curso     = trim($input['curso'] ?? '');
    $dni       = normalizar_dni($input['dni'] ?? '');
    $tipos     = normalizar_tipos($input['tipo_usuario'] ?? []);

    $errores = [];
    if ($nombre === '')    $errores[] = 'El nombre es obligatorio.';
    if ($apellido === '')  $errores[] = 'El apellido es obligatorio.';
    if ($dni === null)     $errores[] = 'El DNI es obligatorio y debe tener entre 6 y 10 dígitos.';
    if ($direccion === '') $errores[] = 'La dirección es obligatoria.';
    if (!$tipos)           $errores[] = 'Elegí al menos un tipo de usuario (' . implode(', ', TIPOS_USUARIO) . ').';
    if ($errores) throw new ApiError(implode(' ', $errores), 422);

    return [
        ':nombre'    => $nombre,
        ':apellido'  => $apellido,
        ':dni'       => $dni,
        ':direccion' => $direccion,
        ':curso'     => $curso !== '' ? $curso : null,
        ':tipo'      => implode(', ', $tipos),
    ];
}

function dni_repetido(PDO $pdo, $dni, $excluirId = 0)
{
    $st = $pdo->prepare("SELECT Id_Usuario FROM Usuario WHERE DNI = :dni AND Id_Usuario <> :id");
    $st->execute([':dni' => $dni, ':id' => $excluirId]);
    return (bool)$st->fetch();
}

ejecutar_api($pdo, function () use ($pdo) {
    $metodo = $_SERVER['REQUEST_METHOD'];

    if ($metodo === 'GET') {
        $sql = "SELECT Id_Usuario, Nombre, Apellido, DNI, Direccion, Curso, Tipo_Usuario FROM Usuario";
        $params = [];

        if (isset($_GET['dni']) && trim($_GET['dni']) !== '') {
            // Búsqueda exacta por DNI (la usa el formulario de préstamos)
            $dni = normalizar_dni($_GET['dni']);
            if ($dni === null) responder(200, ['ok' => true, 'data' => []]);
            $sql .= " WHERE DNI = :dni";
            $params[':dni'] = $dni;
        } elseif (trim($_GET['q'] ?? '') !== '') {
            // Con PDO sin emulación cada marcador debe tener un nombre único.
            $q = trim($_GET['q']);
            $sql .= " WHERE Nombre LIKE :q1 OR Apellido LIKE :q2 OR DNI LIKE :q3
                         OR CONCAT(Nombre, ' ', Apellido) LIKE :q4 OR Id_Usuario = :qid";
            $params[':q1'] = $params[':q2'] = $params[':q3'] = $params[':q4'] = "%{$q}%";
            $params[':qid'] = is_numeric($q) ? (int)$q : -1;
        }

        $stmt = $pdo->prepare($sql . " ORDER BY Id_Usuario DESC");
        $stmt->execute($params);
        responder(200, ['ok' => true, 'data' => $stmt->fetchAll()]);
    }

    if ($metodo === 'POST') {
        $input  = leer_input();
        $accion = $input['accion'] ?? 'crear';

        if ($accion === 'crear') {
            $d = datos_usuario($input);
            if (dni_repetido($pdo, $d[':dni'])) {
                throw new ApiError('Ya existe un usuario con ese DNI.', 409);
            }
            $pdo->prepare(
                "INSERT INTO Usuario (Nombre, Apellido, DNI, Direccion, Curso, Tipo_Usuario)
                 VALUES (:nombre, :apellido, :dni, :direccion, :curso, :tipo)"
            )->execute($d);
            $id = (int)$pdo->lastInsertId();
            responder(200, [
                'ok' => true, 'data' => ['Id_Usuario' => $id],
                'msg' => "Usuario creado correctamente con ID {$id}.",
            ]);
        }

        if ($accion === 'editar') {
            $id = (int)($input['id_usuario'] ?? 0);
            $chk = $pdo->prepare("SELECT Id_Usuario FROM Usuario WHERE Id_Usuario = :id");
            $chk->execute([':id' => $id]);
            if (!$chk->fetch()) throw new ApiError('El usuario no existe.', 404);

            $d = datos_usuario($input);
            if (dni_repetido($pdo, $d[':dni'], $id)) {
                throw new ApiError('Ya existe otro usuario con ese DNI.', 409);
            }
            $d[':id'] = $id;
            $pdo->prepare(
                "UPDATE Usuario SET Nombre = :nombre, Apellido = :apellido, DNI = :dni,
                        Direccion = :direccion, Curso = :curso, Tipo_Usuario = :tipo
                  WHERE Id_Usuario = :id"
            )->execute($d);
            responder(200, ['ok' => true, 'msg' => 'Usuario actualizado correctamente.']);
        }

        throw new ApiError('Acción no válida.', 400);
    }

    throw new ApiError('Método no permitido.', 405);
});
