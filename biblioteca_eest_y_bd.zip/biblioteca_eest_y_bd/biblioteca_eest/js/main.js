// ============================================================
// main.js — Biblioteca EEST
// Maneja: pestañas, altas y EDICIONES por formulario (AJAX),
// listados y búsquedas de Usuarios, Inventario y Préstamos.
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initModal();
  initUsuarios();
  initInventario();
  initPrestamos();
});

// Últimos datos cargados en cada tabla (los botones "Editar" los usan)
const cache = { usuarios: {}, items: {}, prestamos: {} };

// ---------------------------------------------------------
// Utilidades generales
// ---------------------------------------------------------
const $ = (id) => document.getElementById(id);

function mostrarMensaje(elId, texto, tipo) {
  const el = $(elId);
  el.textContent = texto;
  el.className = 'msg ' + tipo;
  el.style.display = 'block';
  clearTimeout(el._timer);
  el._timer = setTimeout(() => { el.style.display = 'none'; }, 5500);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function llamarApi(url, opciones = {}) {
  const resp = await fetch(url, opciones);
  let data;
  try {
    data = await resp.json();
  } catch (e) {
    throw new Error('Respuesta inválida del servidor.');
  }
  if (!resp.ok || data.ok === false) {
    throw new Error(data.error || 'Ocurrió un error inesperado.');
  }
  return data;
}

function postApi(url, cuerpo) {
  return llamarApi(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(cuerpo),
  });
}

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

function horaCorta(h) { return h ? String(h).slice(0, 5) : '-'; }

// ---------------------------------------------------------
// Navegación por pestañas (al entrar se refrescan los datos)
// ---------------------------------------------------------
function initTabs() {
  const botones = document.querySelectorAll('.tab-btn');
  botones.forEach(btn => {
    btn.addEventListener('click', () => {
      botones.forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      $('tab-' + btn.dataset.tab).classList.add('active');

      if (btn.dataset.tab === 'usuarios') cargarUsuarios();
      if (btn.dataset.tab === 'inventario') cargarInventario();
      if (btn.dataset.tab === 'prestamos') cargarPrestamos();
    });
  });
}

// ---------------------------------------------------------
// Ventana de edición (modal)
// ---------------------------------------------------------
let modalSubmit = null;

function initModal() {
  const overlay = $('modal');
  $('modal-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (modalSubmit) await modalSubmit($('modal-form'));
  });
  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) cerrarModal(); });
  overlay.addEventListener('click', (e) => { if (e.target.closest('[data-cerrar-modal]')) cerrarModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !overlay.hidden) cerrarModal(); });
}

function abrirModal(titulo, camposHtml, onSubmit) {
  $('modal-titulo').textContent = titulo;
  $('modal-msg').style.display = 'none';
  $('modal-form').innerHTML = camposHtml + `
    <div class="form-actions">
      <button type="submit" class="btn">Guardar cambios</button>
      <button type="button" class="btn secundario" data-cerrar-modal>Cancelar</button>
    </div>`;
  modalSubmit = onSubmit;
  $('modal').hidden = false;
  document.body.classList.add('modal-abierto');
  const primero = $('modal-form').querySelector('input:not([type=checkbox]), select');
  if (primero) primero.focus();
}

function cerrarModal() {
  $('modal').hidden = true;
  $('modal-form').innerHTML = '';
  modalSubmit = null;
  document.body.classList.remove('modal-abierto');
}

// ---------------------------------------------------------
// Componentes reutilizables
// ---------------------------------------------------------

/** Casillas Alumno / Profesor / Preceptor (se puede marcar más de una). */
function htmlTipos(seleccionados = []) {
  const sel = seleccionados.map(s => s.toLowerCase());
  return window.TIPOS_USUARIO.map(t => `
    <label class="check"><input type="checkbox" name="tipo_usuario" value="${escapeHtml(t)}"
      ${sel.includes(t.toLowerCase()) ? 'checked' : ''}> ${escapeHtml(t)}</label>`).join('');
}

function leerTipos(contenedor) {
  return Array.from(contenedor.querySelectorAll('input[name=tipo_usuario]:checked')).map(c => c.value);
}

/** Campo DNI que muestra en vivo a qué usuario corresponde. */
function vincularDni(input, estadoEl) {
  let usuario = null;
  let ultimaPeticion = 0;

  const mostrar = (texto, clase) => { estadoEl.textContent = texto; estadoEl.className = 'estado-campo ' + (clase || ''); };

  const consultar = debounce(async () => {
    const dni = input.value.trim();
    usuario = null;
    if (!dni) { mostrar('', ''); return; }
    const mia = ++ultimaPeticion;
    try {
      const res = await llamarApi('api/usuarios.php?dni=' + encodeURIComponent(dni));
      if (mia !== ultimaPeticion) return; // llegó tarde una respuesta vieja
      if (res.data.length) {
        usuario = res.data[0];
        mostrar(`✔ ${usuario.Nombre} ${usuario.Apellido} (${usuario.Tipo_Usuario})`, 'ok');
      } else {
        mostrar('✖ No hay ningún usuario con ese DNI.', 'error');
      }
    } catch (err) {
      if (mia === ultimaPeticion) mostrar(err.message, 'error');
    }
  }, 300);

  input.addEventListener('input', () => { usuario = null; mostrar('Buscando...', ''); consultar(); });
  return {
    getUsuario: () => usuario,
    refrescar: () => { mostrar('Buscando...', ''); consultar(); },
    limpiar: () => { usuario = null; ultimaPeticion++; mostrar('', ''); },
  };
}

/**
 * Selector de material con barra de búsqueda.
 * opciones.maximoDe(item) -> cuántos ejemplares se pueden elegir de ese material
 *                            (por defecto, los disponibles).
 * opciones.onChange()     -> se llama al elegir o quitar el material.
 */
function crearSelectorMaterial(contenedor, opciones = {}) {
  const maximoDe = opciones.maximoDe || ((it) => Number(it.Cantidad_Disponible));
  let seleccion = null;
  let resultados = [];

  contenedor.innerHTML = `
    <div class="autocomplete">
      <input type="text" class="sel-buscar" ${opciones.idInput ? `id="${opciones.idInput}"` : ''}
             placeholder="Escribí para buscar el material..." autocomplete="off">
      <ul class="autocomplete-list" hidden></ul>
    </div>
    <div class="sel-elegido" hidden></div>`;

  const caja = contenedor.querySelector('.autocomplete');
  const input = contenedor.querySelector('.sel-buscar');
  const lista = contenedor.querySelector('.autocomplete-list');
  const elegido = contenedor.querySelector('.sel-elegido');

  let numeroBusqueda = 0;
  async function buscar() {
    const q = input.value.trim();
    const mia = ++numeroBusqueda;
    try {
      const res = await llamarApi('api/inventario.php?limite=15&q=' + encodeURIComponent(q));
      if (mia !== numeroBusqueda) return; // llegó tarde: ya hay una búsqueda más nueva
      resultados = res.data || [];
    } catch (err) {
      if (mia !== numeroBusqueda) return;
      resultados = [];
      lista.innerHTML = `<li class="vacio">${escapeHtml(err.message)}</li>`;
      lista.hidden = false;
      return;
    }
    if (!resultados.length) {
      lista.innerHTML = '<li class="vacio">No se encontraron materiales.</li>';
    } else {
      lista.innerHTML = resultados.map((it, idx) => {
        const bloqueado = maximoDe(it) < 1;
        return `<li class="autocomplete-item ${bloqueado ? 'sin-stock' : ''}" data-idx="${idx}">
          <strong>${escapeHtml(it.Nombre)}</strong>
          <span class="meta">${escapeHtml(it.Tipo_Item)}${it.Autor ? ' · ' + escapeHtml(it.Autor) : ''}
            · ID ${escapeHtml(it.Id_Item)}</span>
          <span class="badge ${Number(it.Cantidad_Disponible) > 0 ? 'disponible' : 'no-disponible'}">
            ${escapeHtml(it.Cantidad_Disponible)} de ${escapeHtml(it.Cantidad)} disponibles</span>
        </li>`;
      }).join('');
    }
    lista.hidden = false;
  }

  const buscarConEspera = debounce(buscar, 250);
  input.addEventListener('input', buscarConEspera);
  input.addEventListener('focus', buscar);
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') lista.hidden = true; });

  // mousedown (y no click) para que el elemento no se oculte antes por el blur del input
  lista.addEventListener('mousedown', (e) => {
    const li = e.target.closest('.autocomplete-item');
    if (!li) return;
    e.preventDefault();
    const item = resultados[Number(li.dataset.idx)];
    if (maximoDe(item) < 1) return; // sin ejemplares: no se puede elegir
    establecer(item);
  });
  document.addEventListener('mousedown', (e) => { if (!caja.contains(e.target)) lista.hidden = true; });

  elegido.addEventListener('click', (e) => { if (e.target.closest('.sel-quitar')) limpiar(true); });

  function establecer(item) {
    seleccion = item;
    input.value = '';
    lista.hidden = true;
    caja.hidden = true;
    elegido.hidden = false;
    elegido.innerHTML = `
      <span class="chip">
        <span><strong>${escapeHtml(item.Nombre)}</strong>
          <span class="meta">${escapeHtml(item.Tipo_Item)} · ID ${escapeHtml(item.Id_Item)}
          · ${escapeHtml(item.Cantidad_Disponible)} de ${escapeHtml(item.Cantidad)} disponibles</span></span>
        <button type="button" class="sel-quitar" title="Cambiar material">Cambiar ✕</button>
      </span>`;
    if (opciones.onChange) opciones.onChange(seleccion);
  }

  function limpiar(avisar) {
    seleccion = null;
    resultados = [];
    input.value = '';
    lista.hidden = true;
    caja.hidden = false;
    elegido.hidden = true;
    elegido.innerHTML = '';
    if (avisar && opciones.onChange) { opciones.onChange(null); input.focus(); }
    else if (opciones.onChange) opciones.onChange(null);
  }

  return {
    getSeleccion: () => seleccion,
    maximo: () => (seleccion ? maximoDe(seleccion) : 0),
    establecer,
    limpiar: () => limpiar(false),
  };
}

/** Mantiene el campo "ejemplares" acorde al material elegido. */
function sincronizarCantidad(selector, inputCant, ayudaEl) {
  const sel = selector.getSeleccion();
  if (!sel) {
    inputCant.disabled = true;
    inputCant.value = 1;
    inputCant.removeAttribute('max');
    ayudaEl.textContent = 'Elegí primero un material.';
    ayudaEl.className = 'estado-campo';
    return;
  }
  const max = selector.maximo();
  inputCant.disabled = max < 1;
  inputCant.max = Math.max(max, 1);
  if (Number(inputCant.value) > max) inputCant.value = Math.max(max, 1);
  if (Number(inputCant.value) < 1) inputCant.value = 1;
  ayudaEl.textContent = max < 1 ? 'No hay ejemplares disponibles.' : `Máximo permitido: ${max}`;
  ayudaEl.className = 'estado-campo ' + (max < 1 ? 'error' : '');
}

// ===========================================================
// USUARIOS
// ===========================================================
function initUsuarios() {
  const form = $('form-usuario');
  const buscador = $('buscar-usuario');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const datos = Object.fromEntries(new FormData(form).entries());
    datos.tipo_usuario = leerTipos(form);

    if (!datos.tipo_usuario.length) {
      mostrarMensaje('msg-usuario', 'Elegí al menos un tipo de usuario.', 'error');
      return;
    }
    try {
      const res = await postApi('api/usuarios.php', { accion: 'crear', ...datos });
      mostrarMensaje('msg-usuario', res.msg || 'Usuario creado correctamente.', 'ok');
      form.reset();
      cargarUsuarios();
    } catch (err) {
      mostrarMensaje('msg-usuario', err.message, 'error');
    }
  });

  buscador.addEventListener('input', debounce(() => cargarUsuarios(), 300));

  $('tabla-usuarios').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-editar-usuario]');
    if (btn) editarUsuario(btn.dataset.editarUsuario);
  });

  cargarUsuarios();
}

async function cargarUsuarios() {
  const tbody = $('tabla-usuarios');
  const q = $('buscar-usuario').value.trim();
  tbody.innerHTML = '<tr><td colspan="8" class="vacio">Cargando...</td></tr>';

  try {
    const res = await llamarApi('api/usuarios.php' + (q ? ('?q=' + encodeURIComponent(q)) : ''));
    const usuarios = res.data || [];
    cache.usuarios = {};
    usuarios.forEach(u => { cache.usuarios[u.Id_Usuario] = u; });

    if (usuarios.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="vacio">No se encontraron usuarios.</td></tr>';
      return;
    }
    tbody.innerHTML = usuarios.map(u => `
      <tr>
        <td>${escapeHtml(u.Id_Usuario)}</td>
        <td>${escapeHtml(u.Nombre)}</td>
        <td>${escapeHtml(u.Apellido)}</td>
        <td>${escapeHtml(u.DNI)}</td>
        <td>${escapeHtml(u.Direccion) || '-'}</td>
        <td>${escapeHtml(u.Curso) || '-'}</td>
        <td>${escapeHtml(u.Tipo_Usuario)}</td>
        <td><button type="button" class="btn chico" data-editar-usuario="${escapeHtml(u.Id_Usuario)}">Editar</button></td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="vacio">Error: ${escapeHtml(err.message)}</td></tr>`;
  }
}

function editarUsuario(id) {
  const u = cache.usuarios[id];
  if (!u) return;
  const tiposActuales = String(u.Tipo_Usuario || '').split(',').map(t => t.trim());

  abrirModal(`Editar usuario #${u.Id_Usuario}`, `
    <div class="form-field"><label>Nombre *</label>
      <input type="text" name="nombre" value="${escapeHtml(u.Nombre)}" required></div>
    <div class="form-field"><label>Apellido *</label>
      <input type="text" name="apellido" value="${escapeHtml(u.Apellido)}" required></div>
    <div class="form-field"><label>DNI *</label>
      <input type="text" name="dni" value="${escapeHtml(u.DNI)}" inputmode="numeric" required></div>
    <div class="form-field"><label>Dirección *</label>
      <input type="text" name="direccion" value="${escapeHtml(u.Direccion)}" required></div>
    <div class="form-field"><label>Curso (opcional)</label>
      <input type="text" name="curso" value="${escapeHtml(u.Curso)}"></div>
    <div class="form-field"><label>Tipo de usuario *</label>
      <div class="checks">${htmlTipos(tiposActuales)}</div></div>
  `, async (f) => {
    const datos = Object.fromEntries(new FormData(f).entries());
    datos.tipo_usuario = leerTipos(f);
    if (!datos.tipo_usuario.length) {
      mostrarMensaje('modal-msg', 'Elegí al menos un tipo de usuario.', 'error');
      return;
    }
    try {
      const res = await postApi('api/usuarios.php', { accion: 'editar', id_usuario: u.Id_Usuario, ...datos });
      cerrarModal();
      mostrarMensaje('msg-usuario', res.msg, 'ok');
      cargarUsuarios();
      cargarPrestamos(); // los préstamos muestran nombre y DNI
    } catch (err) {
      mostrarMensaje('modal-msg', err.message, 'error');
    }
  });
}

// ===========================================================
// INVENTARIO
// ===========================================================
function initInventario() {
  const form = $('form-inventario');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const datos = Object.fromEntries(new FormData(form).entries());

    try {
      const res = await postApi('api/inventario.php', { accion: 'crear', ...datos });
      mostrarMensaje('msg-inventario', res.msg || 'Material registrado correctamente.', 'ok');
      form.reset();
      $('i-cantidad').value = 1;
      cargarInventario();
    } catch (err) {
      mostrarMensaje('msg-inventario', err.message, 'error');
    }
  });

  $('btn-buscar-inventario').addEventListener('click', () => cargarInventario());
  $('btn-limpiar-inventario').addEventListener('click', () => {
    ['inv-id', 'inv-tipo', 'inv-nombre', 'inv-autor', 'inv-editorial'].forEach(id => { $(id).value = ''; });
    cargarInventario();
  });

  ['inv-tipo', 'inv-nombre', 'inv-autor', 'inv-editorial', 'inv-id'].forEach(id => {
    $(id).addEventListener('input', debounce(() => cargarInventario(), 350));
  });

  $('tabla-inventario').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-editar-item]');
    if (btn) editarItem(btn.dataset.editarItem);
  });

  cargarInventario();
}

async function cargarInventario() {
  const tbody = $('tabla-inventario');
  tbody.innerHTML = '<tr><td colspan="10" class="vacio">Cargando...</td></tr>';

  const params = new URLSearchParams();
  const filtros = { id: 'inv-id', tipo: 'inv-tipo', nombre: 'inv-nombre', autor: 'inv-autor', editorial: 'inv-editorial' };
  for (const [clave, elId] of Object.entries(filtros)) {
    const v = $(elId).value.trim();
    if (v) params.set(clave, v);
  }

  try {
    const res = await llamarApi('api/inventario.php?' + params.toString());
    const items = res.data || [];
    cache.items = {};
    items.forEach(i => { cache.items[i.Id_Item] = i; });

    if (items.length === 0) {
      tbody.innerHTML = '<tr><td colspan="10" class="vacio">No se encontraron materiales.</td></tr>';
      return;
    }

    tbody.innerHTML = items.map(i => {
      const hay = Number(i.Cantidad_Disponible) > 0;
      const estado = hay
        ? '<span class="badge disponible">Disponible</span>'
        : '<span class="badge no-disponible">No disponible</span>';
      return `
        <tr>
          <td>${escapeHtml(i.Id_Item)}</td>
          <td>${escapeHtml(i.Tipo_Item)}</td>
          <td>${escapeHtml(i.Nombre)}</td>
          <td>${escapeHtml(i.Autor) || '-'}</td>
          <td>${escapeHtml(i.Editorial) || '-'}</td>
          <td>${escapeHtml(i.Isbn) || '-'}</td>
          <td>${escapeHtml(i.Cantidad)}</td>
          <td><strong>${escapeHtml(i.Cantidad_Disponible)}</strong> de ${escapeHtml(i.Cantidad)}</td>
          <td>${estado}</td>
          <td><button type="button" class="btn chico" data-editar-item="${escapeHtml(i.Id_Item)}">Editar</button></td>
        </tr>`;
    }).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="10" class="vacio">Error: ${escapeHtml(err.message)}</td></tr>`;
  }
}

function editarItem(id) {
  const it = cache.items[id];
  if (!it) return;
  const prestados = Number(it.Cantidad) - Number(it.Cantidad_Disponible);
  const opcionesTipo = window.TIPOS_ITEM.map(t =>
    `<option value="${escapeHtml(t)}" ${t === String(it.Tipo_Item).toLowerCase() ? 'selected' : ''}>${escapeHtml(t.charAt(0).toUpperCase() + t.slice(1))}</option>`
  ).join('');

  abrirModal(`Editar material #${it.Id_Item}`, `
    <div class="form-field"><label>Tipo de material *</label>
      <select name="tipo_item" required>${opcionesTipo}</select></div>
    <div class="form-field"><label>Título / Nombre *</label>
      <input type="text" name="nombre" value="${escapeHtml(it.Nombre)}" required></div>
    <div class="form-field"><label>Autor</label>
      <input type="text" name="autor" value="${escapeHtml(it.Autor)}"></div>
    <div class="form-field"><label>Editorial</label>
      <input type="text" name="editorial" value="${escapeHtml(it.Editorial)}"></div>
    <div class="form-field"><label>ISBN</label>
      <input type="text" name="isbn" value="${escapeHtml(it.Isbn)}"></div>
    <div class="form-field"><label>Ejemplares totales *</label>
      <input type="number" name="cantidad" min="${Math.max(prestados, 1)}" value="${escapeHtml(it.Cantidad)}" required>
      <small class="estado-campo">Ahora hay ${escapeHtml(prestados)} prestado(s) y ${escapeHtml(it.Cantidad_Disponible)} disponible(s).</small></div>
  `, async (f) => {
    const datos = Object.fromEntries(new FormData(f).entries());
    try {
      const res = await postApi('api/inventario.php', { accion: 'editar', id_item: it.Id_Item, ...datos });
      cerrarModal();
      mostrarMensaje('msg-inventario', res.msg, 'ok');
      cargarInventario();
      cargarPrestamos(); // los préstamos muestran el nombre del material
    } catch (err) {
      mostrarMensaje('modal-msg', err.message, 'error');
    }
  });
}

// ===========================================================
// PRÉSTAMOS
// ===========================================================
function initPrestamos() {
  const form = $('form-prestamo');
  const dniInput = $('p-dni');
  const cantInput = $('p-cantidad');
  const cantAyuda = $('p-cantidad-ayuda');

  const dni = vincularDni(dniInput, $('p-dni-estado'));
  const selector = crearSelectorMaterial($('p-material-selector'), {
    idInput: 'p-material-buscar',
    onChange: () => sincronizarCantidad(selector, cantInput, cantAyuda),
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const sel = selector.getSeleccion();
    if (!sel) {
      mostrarMensaje('msg-prestamo', 'Buscá y elegí el material a prestar.', 'error');
      return;
    }
    try {
      const res = await postApi('api/prestamos.php', {
        accion: 'crear',
        dni: dniInput.value.trim(),
        id_item: sel.Id_Item,
        cantidad: cantInput.value,
      });
      mostrarMensaje('msg-prestamo', res.msg || 'Préstamo registrado correctamente.', 'ok');
      form.reset();
      cargarPrestamos();
      cargarInventario(); // refleja los ejemplares prestados
    } catch (err) {
      mostrarMensaje('msg-prestamo', err.message, 'error');
      // el stock pudo cambiar mientras tanto: se vuelve a leer el material elegido
      try {
        const r = await llamarApi('api/inventario.php?id=' + encodeURIComponent(sel.Id_Item));
        if (r.data[0]) selector.establecer(r.data[0]);
      } catch (_) { /* sin cambios */ }
    }
  });

  // "Limpiar" restablece también el DNI en vivo y el selector de material
  form.addEventListener('reset', () => {
    dni.limpiar();
    selector.limpiar();
  });

  $('btn-buscar-prestamos').addEventListener('click', () => cargarPrestamos());
  $('btn-limpiar-prestamos').addEventListener('click', () => {
    ['pr-material', 'pr-usuario', 'pr-dni', 'pr-id-usuario'].forEach(id => { $(id).value = ''; });
    cargarPrestamos();
  });
  ['pr-material', 'pr-usuario', 'pr-dni', 'pr-id-usuario'].forEach(id => {
    $(id).addEventListener('input', debounce(() => cargarPrestamos(), 350));
  });

  $('tabla-prestamos').addEventListener('click', (e) => {
    const ed = e.target.closest('[data-editar-prestamo]');
    if (ed) { editarPrestamo(ed.dataset.editarPrestamo); return; }
    const dev = e.target.closest('[data-devolver]');
    if (dev) marcarDevuelto(dev.dataset.devolver);
  });

  cargarPrestamos();
}

async function cargarPrestamos() {
  const tbody = $('tabla-prestamos');
  tbody.innerHTML = '<tr><td colspan="10" class="vacio">Cargando...</td></tr>';

  const params = new URLSearchParams();
  const filtros = { material: 'pr-material', usuario: 'pr-usuario', dni: 'pr-dni', id_usuario: 'pr-id-usuario' };
  for (const [clave, elId] of Object.entries(filtros)) {
    const v = $(elId).value.trim();
    if (v) params.set(clave, v);
  }

  try {
    const res = await llamarApi('api/prestamos.php?' + params.toString());
    const prestamos = res.data || [];
    cache.prestamos = {};
    prestamos.forEach(p => { cache.prestamos[p.Id_Prestamo] = p; });

    if (prestamos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="10" class="vacio">No se encontraron préstamos.</td></tr>';
      return;
    }

    tbody.innerHTML = prestamos.map(p => {
      const devuelto = p.Estado_Devuelto === 'si';
      const estado = devuelto
        ? '<span class="badge devuelto">Devuelto</span>'
        : '<span class="badge pendiente">Pendiente</span>';
      const id = escapeHtml(p.Id_Prestamo);
      const acciones = `<div class="acciones">
          <button type="button" class="btn chico secundario" data-editar-prestamo="${id}">Editar</button>
          ${devuelto ? '' : `<button type="button" class="btn chico" data-devolver="${id}">Marcar devuelto</button>`}
        </div>`;

      return `
        <tr>
          <td>${id}</td>
          <td>${escapeHtml(p.Usuario_Nombre)} ${escapeHtml(p.Usuario_Apellido)}</td>
          <td>${escapeHtml(p.DNI)}</td>
          <td>${escapeHtml(p.Item_Nombre)}</td>
          <td>${escapeHtml(p.Cantidad)}</td>
          <td>${escapeHtml(p.Fecha_Prestamo)}</td>
          <td>${escapeHtml(horaCorta(p.Hora_Prestamo))}</td>
          <td>${escapeHtml(horaCorta(p.Hora_Devolucion))}</td>
          <td>${estado}</td>
          <td>${acciones}</td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="10" class="vacio">Error: ${escapeHtml(err.message)}</td></tr>`;
  }
}

function editarPrestamo(id) {
  const p = cache.prestamos[id];
  if (!p) return;
  const devuelto = p.Estado_Devuelto === 'si';

  abrirModal(`Editar préstamo #${p.Id_Prestamo}`, `
    <div class="form-field">
      <label for="m-dni">DNI del usuario *</label>
      <input type="text" id="m-dni" name="dni" value="${escapeHtml(p.DNI)}" inputmode="numeric" required>
      <small id="m-dni-estado" class="estado-campo"></small>
    </div>
    <div class="form-field ancho">
      <label for="m-material-buscar">Material *</label>
      <div id="m-material-selector"></div>
    </div>
    <div class="form-field">
      <label for="m-cantidad">Ejemplares del préstamo *</label>
      <input type="number" id="m-cantidad" name="cantidad" min="1" value="${escapeHtml(p.Cantidad)}" required>
      <small id="m-cantidad-ayuda" class="estado-campo"></small>
    </div>
    <p class="nota ancho">${devuelto
      ? 'Este préstamo ya fue devuelto: los cambios corrigen el registro y no afectan el stock actual.'
      : 'Al guardar, el inventario se recalcula con el nuevo material y la nueva cantidad.'}</p>
  `, async (f) => {
    const sel = selector.getSeleccion();
    if (!sel) {
      mostrarMensaje('modal-msg', 'Elegí el material del préstamo.', 'error');
      return;
    }
    try {
      const res = await postApi('api/prestamos.php', {
        accion: 'editar',
        id_prestamo: p.Id_Prestamo,
        dni: $('m-dni').value.trim(),
        id_item: sel.Id_Item,
        cantidad: $('m-cantidad').value,
      });
      cerrarModal();
      mostrarMensaje('msg-prestamo', res.msg, 'ok');
      cargarPrestamos();
      cargarInventario();
    } catch (err) {
      mostrarMensaje('modal-msg', err.message, 'error');
    }
  });

  // Los ejemplares que este mismo préstamo ya tiene reservados no cuentan como "ocupados"
  const maximoDe = (it) => {
    if (devuelto) return Number(it.Cantidad);
    const propios = Number(it.Id_Item) === Number(p.Id_Item) ? Number(p.Cantidad) : 0;
    return Number(it.Cantidad_Disponible) + propios;
  };
  const cantInput = $('m-cantidad');
  const selector = crearSelectorMaterial($('m-material-selector'), {
    idInput: 'm-material-buscar',
    maximoDe,
    onChange: () => sincronizarCantidad(selector, cantInput, $('m-cantidad-ayuda')),
  });
  const dni = vincularDni($('m-dni'), $('m-dni-estado'));
  dni.refrescar();

  selector.establecer({
    Id_Item: p.Id_Item, Nombre: p.Item_Nombre, Tipo_Item: p.Tipo_Item, Autor: p.Item_Autor,
    Cantidad: p.Item_Total, Cantidad_Disponible: p.Item_Disponible,
  });
  cantInput.value = p.Cantidad; // establecer() ajusta el valor; se restituye el original
  sincronizarCantidad(selector, cantInput, $('m-cantidad-ayuda'));
}

async function marcarDevuelto(idPrestamo) {
  try {
    const res = await postApi('api/prestamos.php', { accion: 'devolver', id_prestamo: Number(idPrestamo) });
    mostrarMensaje('msg-prestamo', res.msg || 'Préstamo marcado como devuelto.', 'ok');
    cargarPrestamos();
    cargarInventario(); // los ejemplares vuelven a estar disponibles
  } catch (err) {
    mostrarMensaje('msg-prestamo', err.message, 'error');
  }
}
